package at.htlpinkafeld.projectmanager.ui;

/**
 * Created by tq on 15-11-20.
 */
public interface FragmentTab {
    void tabBecameVisible();
}